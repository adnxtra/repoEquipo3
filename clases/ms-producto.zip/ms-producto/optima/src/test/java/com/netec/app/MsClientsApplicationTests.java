package com.netec.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsClientsApplicationTests {

	@Test
	void contextLoads() {
	}

}
