package com.pe.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pe.app.entities.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
}
