package com.pe.app.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pe.app.entities.Producto;
import com.pe.app.repository.ProductoRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ProductoServiceImpl implements IProductoService {

 
    private final ProductoRepository ProductoRepository;
	
    public ProductoServiceImpl(ProductoRepository ProductoRepository) {
        this.ProductoRepository = ProductoRepository;
    }
    
	@Override
	public List<Producto> findAll() {
		return (List<Producto>)ProductoRepository.findAll();
	}

	@Override
	public Optional<Producto> findById(Long id) {
		return ProductoRepository.findById(id);
	}

	@Override
	public Producto save(Producto producto) {
		 return ProductoRepository.save(producto);
	}

	@Override
	public void deleteById(Long id) {
		ProductoRepository.deleteById(id);
	}
   
}
