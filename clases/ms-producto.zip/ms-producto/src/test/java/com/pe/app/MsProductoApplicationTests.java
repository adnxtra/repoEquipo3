package com.pe.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsProductoApplicationTests {

	@Test
	void contextLoads() {
	}

}
